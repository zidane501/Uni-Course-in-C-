#ifndef H_5_10_H
#define H_5_10_H

void guassian_elimination(double **A, double *b, double *u, int n);
//void P_matrix(double **P, int N, int row1, int row2);
//void Multiply1( double **res , double **A, double **B, int ARows , int ACols , int BRows , int BCols );
//void matrixPrintOut(double **M, int n, std::string name);

#endif
